
import React from 'react';
import Header from './components/Header';
import StudyPlan from './components/StudyPlan';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans">
      <main className="container mx-auto px-4 py-8 md:py-12">
        <Header />
        <StudyPlan />
        <footer className="text-center mt-12 text-slate-500">
          <p>Embrace the learning journey. Consistency is key!</p>
          <p>&copy; 2024 Zero to Hero Plan</p>
        </footer>
      </main>
    </div>
  );
};

export default App;
