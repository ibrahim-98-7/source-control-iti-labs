
import React from 'react';
import { DayPlan } from '../types';
import ChevronDownIcon from './icons/ChevronDownIcon';
import TargetIcon from './icons/TargetIcon';
import BookOpenIcon from './icons/BookOpenIcon';
import CodeIcon from './icons/CodeIcon';
import LinkIcon from './icons/LinkIcon';
import LightBulbIcon from './icons/LightBulbIcon';

interface DayAccordionProps {
  dayPlan: DayPlan;
  isOpen: boolean;
  onToggle: () => void;
}

const DayAccordion: React.FC<DayAccordionProps> = ({ dayPlan, isOpen, onToggle }) => {
  const { day, title, objective, concepts, task, resources, isReview, tip } = dayPlan;

  const sectionClasses = "flex items-start space-x-3";
  const iconClasses = "w-5 h-5 mt-1 text-blue-400 flex-shrink-0";
  const titleClasses = "text-lg font-semibold text-slate-300 mb-1";
  const listClasses = "list-disc list-inside text-slate-400 space-y-1";

  return (
    <div className="border border-slate-700 rounded-lg bg-slate-800/50 overflow-hidden transition-all duration-300">
      <button
        onClick={onToggle}
        className="w-full flex justify-between items-center p-4 text-left focus:outline-none focus:ring-2 focus:ring-blue-500"
        aria-expanded={isOpen}
        aria-controls={`day-${day}-content`}
      >
        <div className="flex items-center">
          <span className={`text-xl font-bold mr-4 ${isReview ? 'text-amber-400' : 'text-blue-400'}`}>
            Day {day}
          </span>
          <span className="text-lg font-medium text-slate-200">{title}</span>
        </div>
        <ChevronDownIcon className={`w-6 h-6 transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      <div
        id={`day-${day}-content`}
        className={`transition-all duration-500 ease-in-out ${isOpen ? 'max-h-[1000px] visible opacity-100' : 'max-h-0 invisible opacity-0'}`}
      >
        <div className="border-t border-slate-700 p-6 space-y-6">
          <div className={sectionClasses}>
            <TargetIcon className={iconClasses} />
            <div>
              <h3 className={titleClasses}>Learning Objective</h3>
              <p className="text-slate-400">{objective}</p>
            </div>
          </div>

          <div className={sectionClasses}>
            <BookOpenIcon className={iconClasses} />
            <div>
              <h3 className={titleClasses}>Key Concepts</h3>
              <ul className={listClasses}>
                {concepts.map((concept, index) => <li key={index}>{concept}</li>)}
              </ul>
            </div>
          </div>
          
          <div className={sectionClasses}>
            <CodeIcon className={iconClasses} />
            <div>
              <h3 className={titleClasses}>Hands-On Task</h3>
              <p className="text-slate-300 bg-slate-700/50 p-3 rounded-md border border-slate-600">{task}</p>
            </div>
          </div>

          <div className={sectionClasses}>
            <LinkIcon className={iconClasses} />
            <div>
              <h3 className={titleClasses}>Resources</h3>
              <ul className={listClasses}>
                {resources.map((resource, index) => <li key={index}>{resource}</li>)}
              </ul>
            </div>
          </div>

          {tip && (
            <div className="flex items-start space-x-3 p-3 bg-blue-900/30 border border-blue-800 rounded-lg">
              <LightBulbIcon className="w-5 h-5 mt-1 text-amber-400 flex-shrink-0" />
              <div>
                <h3 className="text-lg font-semibold text-amber-300 mb-1">Expert Tip</h3>
                <p className="text-slate-300">{tip}</p>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default DayAccordion;
