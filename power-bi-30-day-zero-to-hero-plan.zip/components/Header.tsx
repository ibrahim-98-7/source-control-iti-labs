
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="text-center mb-10">
      <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-teal-300 mb-2">
        Power BI 30-Day Zero to Hero Plan
      </h1>
      <p className="text-lg text-slate-400 max-w-3xl mx-auto">
        Your comprehensive, day-by-day roadmap to mastering Microsoft Power BI. Follow this structured plan to go from absolute beginner to a confident data professional.
      </p>
    </header>
  );
};

export default Header;
