
import React, { useState } from 'react';
import { studyPlan } from '../constants/planData';
import { Phase } from '../types';
import DayAccordion from './DayAccordion';

const StudyPlan: React.FC = () => {
  const [openDay, setOpenDay] = useState<number | null>(1);

  const handleToggle = (day: number) => {
    setOpenDay(prevOpenDay => (prevOpenDay === day ? null : day));
  };

  return (
    <div className="space-y-12">
      {studyPlan.map((phase: Phase, phaseIndex: number) => (
        <section key={phaseIndex} aria-labelledby={`phase-title-${phaseIndex}`}>
          <div className="mb-6">
            <h2 id={`phase-title-${phaseIndex}`} className="text-2xl md:text-3xl font-bold text-slate-200 border-l-4 border-blue-500 pl-4">
              {phase.title}
            </h2>
            <p className="text-slate-400 pl-5">{phase.duration}</p>
          </div>
          <div className="space-y-2">
            {phase.days.map(dayPlan => (
              <DayAccordion
                key={dayPlan.day}
                dayPlan={dayPlan}
                isOpen={openDay === dayPlan.day}
                onToggle={() => handleToggle(dayPlan.day)}
              />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
};

export default StudyPlan;
