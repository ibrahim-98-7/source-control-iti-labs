
export interface DayPlan {
  day: number;
  title: string;
  objective: string;
  concepts: string[];
  task: string;
  resources: string[];
  isReview?: boolean;
  tip?: string;
}

export interface Phase {
  title: string;
  duration: string;
  days: DayPlan[];
}
