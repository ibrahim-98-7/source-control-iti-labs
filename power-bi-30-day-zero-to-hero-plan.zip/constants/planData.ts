
import { Phase } from '../types';

export const studyPlan: Phase[] = [
  {
    title: "Phase 1: Foundation & Setup",
    duration: "Days 1-7",
    days: [
      {
        day: 1,
        title: "Understanding the Landscape & Setup",
        objective: "Understand what Power BI is, its components, and install the necessary software.",
        concepts: [
          "What is Business Intelligence (BI)?",
          "Difference between Power BI Desktop, Power BI Service, and Power BI Mobile.",
          "The role of Power BI in data-driven decision making."
        ],
        task: "Download and install Power BI Desktop. Open it and explore the interface. Identify the three main views: Report, Data, and Model.",
        resources: [
          "Microsoft Learn: 'Get Started with Power BI'",
          "YouTube: 'What is Power BI? A Beginner's Guide'"
        ],
        tip: "Don't be intimidated by the interface. Your goal today is just to get familiar with where things are."
      },
      {
        day: 2,
        title: "The Power BI Ecosystem",
        objective: "Learn the typical workflow in Power BI from data to dashboard.",
        concepts: [
          "The five pillars of Power BI: Get Data, Transform Data, Model Data, Visualize Data, and Share.",
          "Understanding Workspaces in Power BI Service.",
          "Difference between a Report and a Dashboard."
        ],
        task: "Draw a diagram of the Power BI workflow. Sign up for a free Power BI Service account to explore its interface.",
        resources: [
          "Microsoft Docs: 'Basic concepts for Power BI service consumers'"
        ]
      },
      {
        day: 3,
        title: "Connecting to Your First Data Source",
        objective: "Learn how to import data from common file types like Excel and CSV.",
        concepts: [
          "The 'Get Data' experience.",
          "Data connectors: understanding the variety of available sources.",
          "Import vs. DirectQuery vs. Live Connection (conceptual overview)."
        ],
        task: "Find a simple dataset online (e.g., a CSV of movie ratings or an Excel file of sales data). Connect to it and load it into Power BI Desktop. View the loaded data in the 'Data' view.",
        resources: [
          "Kaggle.com for free datasets.",
          "YouTube: 'Power BI - How to connect to Excel and CSV files'"
        ]
      },
      {
        day: 4,
        title: "Building Your First Visuals",
        objective: "Create basic charts and understand how they interact.",
        concepts: [
          "The Visualizations Pane.",
          "Fields, Values, Axis, and Legend wells.",
          "Creating Bar Charts, Column Charts, and Pie Charts.",
          "Basic formatting: titles, data labels, colors."
        ],
        task: "Using the data from yesterday, create a simple report page. Add a bar chart showing sales by region and a pie chart showing sales by category. Click on a bar and see how the pie chart filters.",
        resources: [
          "Microsoft Learn: 'Work with visuals in Power BI reports'"
        ],
        tip: "Drag and drop is your best friend here. Experiment by moving fields into different wells to see what happens."
      },
      {
        day: 5,
        title: "Filtering and Slicing Data",
        objective: "Learn to filter data at different levels to create interactive reports.",
        concepts: [
          "The Filters Pane: Visual-level, Page-level, and Report-level filters.",
          "Understanding Slicers for user-driven filtering.",
          "Different slicer types (list, dropdown, between)."
        ],
        task: "Add a 'Year' slicer to your report. Add a page-level filter to only show data for a specific country. See how the visuals update dynamically.",
        resources: [
          "YouTube: 'Power BI Slicers and Filters Tutorial'"
        ]
      },
      {
        day: 6,
        title: "Publishing and Sharing",
        objective: "Understand how to publish a report to the cloud and share it.",
        concepts: [
          "The 'Publish' button in Power BI Desktop.",
          "Navigating to your report in Power BI Service.",
          "Basic sharing options (conceptual).",
          "Creating a simple Dashboard by pinning visuals."
        ],
        task: "Publish the report you've built this week to your 'My Workspace' in the Power BI Service. Pin at least two visuals to a new dashboard named 'My First Dashboard'.",
        resources: [
          "Microsoft Docs: 'Publish reports from Power BI Desktop to the Power BI service'"
        ]
      },
      {
        day: 7,
        title: "Weekly Review & Practice",
        objective: "Consolidate the knowledge from Week 1.",
        concepts: [
          "Review all concepts from Day 1 to Day 6."
        ],
        task: "Start from scratch. Find a new, simple dataset. Go through the entire workflow: connect to data, build 3-4 visuals on a report page, add slicers, and publish it to the Power BI Service. Try to do it without looking at the tutorials.",
        resources: [
          "Your notes from the week."
        ],
        isReview: true
      }
    ],
  },
  {
    title: "Phase 2: Data Wrangling & Transformation",
    duration: "Days 8-15",
    days: [
      {
        day: 8,
        title: "Introduction to Power Query Editor",
        objective: "Understand the role of Power Query and navigate its interface.",
        concepts: [
          "What is ETL (Extract, Transform, Load)?",
          "The Power Query Editor interface: Ribbon, Queries pane, Data preview, Applied Steps.",
          "The importance of data shaping and cleaning."
        ],
        task: "Load a 'messy' dataset (one with empty rows, mixed data types, etc.). Click 'Transform Data' to open the Power Query Editor. Identify each part of the interface. Notice the 'Applied Steps' that are automatically created.",
        resources: [
          "Find messy datasets by searching for 'sample dirty data csv' online.",
          "YouTube: 'Power Query for Beginners'"
        ],
        tip: "Power Query is where the magic really begins. Every click you make is recorded as a step, creating a repeatable cleaning process."
      },
       {
        day: 9,
        title: "Basic Transformations",
        objective: "Perform fundamental data cleaning operations in Power Query.",
        concepts: [
          "Changing Data Types (Text, Whole Number, Decimal, Date).",
          "Removing columns and rows.",
          "Filtering data within Power Query.",
          "Replacing values."
        ],
        task: "Using your messy dataset, change the data types of columns to be correct. Remove any columns you don't need. Filter out rows that have null values in a key column. Replace a specific text value (e.g., 'N/A' with null).",
        resources: [
          "Microsoft Docs: 'Tutorial: Shape and combine data in Power BI Desktop'"
        ]
      },
      {
        day: 10,
        title: "Text & Number Transformations",
        objective: "Learn to manipulate text and numeric data.",
        concepts: [
          "Splitting columns by delimiter.",
          "Merging columns.",
          "Formatting text (Uppercase, Lowercase, Capitalize).",
          "Using Trim & Clean.",
          "Basic numeric calculations (Add, Multiply, etc. from the 'Add Column' tab)."
        ],
        task: "Create a 'Full Name' column by merging 'First Name' and 'Last Name' columns. Split a 'Location' column (e.g., 'City, State') into two separate columns. Standardize a text column by making it all uppercase.",
        resources: [
          "YouTube: 'Top 10 Power Query Text Transformations'"
        ]
      },
      {
        day: 11,
        title: "Pivoting & Unpivoting Data",
        objective: "Understand how to restructure or reshape tables for optimal analysis.",
        concepts: [
          "What is 'wide' vs. 'tall' data?",
          "Unpivot Columns: Turning columns into rows (most common).",
          "Pivot Columns: Turning rows into columns."
        ],
        task: "Find a dataset that is in a 'wide' format (e.g., sales data with a separate column for each month: Jan, Feb, Mar...). Use 'Unpivot Columns' to transform it into a 'tall' format with two new columns: 'Month' and 'Sales'. This is a critical skill!",
        resources: [
          "Microsoft Docs: 'Unpivot columns (Power Query)'"
        ]
      },
      {
        day: 12,
        title: "Grouping and Aggregating Data",
        objective: "Summarize data within Power Query before loading it to the model.",
        concepts: [
          "The 'Group By' feature.",
          "Performing aggregate functions (Sum, Count, Average, Min, Max).",
          "Basic vs. Advanced grouping."
        ],
        task: "Using a sales dataset, use 'Group By' to create a new, summarized table that shows the total sales amount for each product category.",
        resources: [
          "YouTube: 'How to use Group By in Power Query'"
        ]
      },
      {
        day: 13,
        title: "Merging & Appending Queries",
        objective: "Learn to combine data from multiple tables or sources.",
        concepts: [
          "Append Queries: Stacking tables with the same structure (like UNION in SQL).",
          "Merge Queries: Joining tables based on a common column (like JOIN in SQL).",
          "Different Join Kinds (Inner, Left Outer, Right Outer, etc.)."
        ],
        task: "Load two separate tables (e.g., 'Sales' and 'Product Details'). Merge them using 'ProductID' to bring the product name into the sales table. If you have sales data for two different years in separate files, append them into a single table.",
        resources: [
          "Microsoft Learn: 'Combine multiple data sources in Power BI Desktop'"
        ]
      },
       {
        day: 14,
        title: "Custom Columns & Intro to M",
        objective: "Create new columns based on logic and get a first look at the M language.",
        concepts: [
          "Adding a Conditional Column using the UI.",
          "The 'Add Custom Column' feature.",
          "Basic M formula syntax (if-then-else statements).",
          "Viewing the M code in the Advanced Editor."
        ],
        task: "Add a conditional column that categorizes sales as 'High' or 'Low' based on an amount (e.g., if sales > 1000 then 'High' else 'Low'). Look at the formula bar and the Advanced Editor to see the M code that was generated.",
        resources: [
          "YouTube: 'Power BI Conditional Columns Made Easy'"
        ],
        tip: "You don't need to be an M code expert, but understanding that it's the language powering everything you do in Power Query is important."
      },
      {
        day: 15,
        title: "Weekly Review & Data Cleaning Challenge",
        objective: "Consolidate data transformation skills from Week 2.",
        concepts: [
          "Review all Power Query concepts from Day 8 to Day 14."
        ],
        task: "Find the messiest dataset you can. Your challenge is to clean and transform it into a perfectly structured table ready for analysis. Document every step you take. Your final table should have correct data types, no errors, and a logical structure.",
        resources: [
          "Data.world and Kaggle are great sources for challenging datasets."
        ],
        isReview: true
      }
    ]
  },
  {
    title: "Phase 3: Data Modeling & DAX Fundamentals",
    duration: "Days 16-22",
    days: [
        {
            day: 16,
            title: "Data Modeling Concepts",
            objective: "Understand the fundamentals of creating a robust and efficient data model.",
            concepts: [
                "What is a Data Model?",
                "Fact Tables vs. Dimension Tables.",
                "Star Schema vs. Snowflake Schema.",
                "The importance of a good schema for performance and DAX simplicity."
            ],
            task: "Load a dataset with multiple tables (e.g., Sales, Products, Customers, Dates). In the Model view, arrange them by identifying which are fact tables (containing numbers/transactions) and which are dimension tables (containing descriptive attributes). Sketch out a star schema for your data on paper.",
            resources: [
                "YouTube: 'Star Schema Explained for Power BI'"
            ],
            tip: "This is one of the most important concepts in all of BI. A good model makes everything else easier!"
        },
        {
            day: 17,
            title: "Creating Relationships",
            objective: "Learn how to connect tables in the Power BI model.",
            concepts: [
                "Primary Keys and Foreign Keys.",
                "Creating relationships by dragging and dropping.",
                "Cardinality (One-to-Many, One-to-One, Many-to-Many).",
                "Cross-filter direction (Single vs. Both)."
            ],
            task: "Using the tables from yesterday, create relationships between your fact table and dimension tables in the Model view. Double-click a relationship line to inspect its properties (cardinality, cross-filter direction).",
            resources: [
                "Microsoft Docs: 'Create and manage relationships in Power BI Desktop'"
            ]
        },
        {
            day: 18,
            title: "Intro to DAX: Calculated Columns vs. Measures",
            objective: "Understand the core concept of DAX and the fundamental difference between calculated columns and measures.",
            concepts: [
                "What is DAX (Data Analysis Expressions)?",
                "Calculated Columns: Row-by-row context, stored in the model, consumes RAM.",
                "Measures: Evaluated at query time, responds to filter context, consumes CPU.",
                "When to use which: The golden rule."
            ],
            task: "Create a calculated column 'Price per Unit' in your sales table (e.g., [SalesAmount] / [Quantity]). Then, create your first measure: Total Sales = SUM(Sales[SalesAmount]). Put both in a table visual and see how they behave when you add a slicer.",
            resources: [
                "SQLBI: 'Calculated Columns and Measures in DAX'"
            ],
            tip: "Embrace the struggle with DAX! The rule of thumb: use a measure unless you absolutely have to use a calculated column."
        },
        {
            day: 19,
            title: "Core Aggregation & Iterator Functions",
            objective: "Learn basic but essential DAX aggregation functions.",
            concepts: [
                "Aggregation functions: SUM, AVERAGE, COUNT, DISTINCTCOUNT, MIN, MAX.",
                "Iterator functions (the 'X' functions): SUMX, AVERAGEX, COUNTX.",
                "Understanding row context within an iterator function."
            ],
            task: "Create measures for: Total Quantity (SUM), Average Sales Price (AVERAGE), Number of Transactions (COUNT), and Number of Unique Customers (DISTINCTCOUNT). Create a SUMX measure for Total Sales: Total Sales (SUMX) = SUMX(Sales, Sales[Quantity] * Sales[Price]).",
            resources: [
                "YouTube: 'SUM vs SUMX in Power BI'"
            ]
        },
        {
            day: 20,
            title: "The CALCULATE Function: The Superpower of DAX",
            objective: "Understand the most important and powerful function in DAX.",
            concepts: [
                "What CALCULATE does: Modifies the filter context.",
                "Syntax: CALCULATE(<expression>, <filter1>, <filter2>,...).",
                "Simple filter modification examples."
            ],
            task: "Create a measure for 'Total Sales'. Now, create a new measure 'Blue Product Sales' = CALCULATE([Total Sales], Products[Color] = \"Blue\"). Create another for 'High Margin Sales' = CALCULATE([Total Sales], Sales[Margin] > 0.4). Put them all on cards to see the results.",
            resources: [
                "SQLBI: 'Introducing CALCULATE in DAX'"
            ]
        },
        {
            day: 21,
            title: "Basic Time Intelligence",
            objective: "Learn to perform common date-based calculations.",
            concepts: [
                "The importance of a dedicated Date Table.",
                "Time Intelligence functions: TOTALYTD, PREVIOUSYEAR, SAMEPERIODLASTYEAR.",
                "Using your Date Table with time intelligence functions."
            ],
            task: "Create a basic Date Table. Mark it as a date table in the Model view. Create a 'Total Sales YTD' measure: Total Sales YTD = TOTALYTD([Total Sales], 'Date'[Date]). Then create a 'Prior Year Sales' measure: PY Sales = CALCULATE([Total Sales], SAMEPERIODLASTYEAR('Date'[Date])).",
            resources: [
                "YouTube: 'Power BI Calendar Table Tutorial'"
            ]
        },
        {
            day: 22,
            title: "Weekly Review & DAX Practice",
            objective: "Consolidate data modeling and DAX concepts from Week 3.",
            concepts: [
                "Review Star Schema, Relationships, Columns vs. Measures, CALCULATE, and Time Intelligence."
            ],
            task: "Create a new Power BI file. Load a dataset and build a proper star schema model. Then, write 10 different DAX measures from scratch. The measures should answer specific business questions like 'What were the sales for our top product category last year?'.",
            resources: [
                "Your notes and DAX formulas from the week."
            ],
isReview: true
        }
    ]
},
{
    title: "Phase 4: Visualization & Report Design",
    duration: "Days 23-28",
    days: [
        {
            day: 23,
            title: "Advanced Visuals & Use Cases",
            objective: "Learn to use more complex visuals to convey specific insights.",
            concepts: [
                "Matrix Visual: For pivot table-like analysis.",
                "Cards & KPI Visuals: For displaying single, important numbers.",
                "Scatter & Line Charts: For showing trends and correlations.",
                "Map Visuals: For geographic data."
            ],
            task: "Create a new report page. Build a Matrix with Product Categories as rows and Years as columns, with Total Sales as the value. Add Card visuals for your key measures. If you have geographic data, create a map visual.",
            resources: [
                "Microsoft Docs: 'Visualization types in Power BI'"
            ]
        },
        {
            day: 24,
            title: "Formatting, Themes, and Layout",
            objective: "Learn to make your reports visually appealing and professional.",
            concepts: [
                "The Formatting Pane in detail.",
                "Using and customizing report themes.",
                "Aligning and distributing visuals.",
                "Using shapes, images, and text boxes for better design.",
                "Mobile layout design."
            ],
            task: "Take one of your existing reports and give it a complete makeover. Create a custom theme with your company's colors. Ensure all visuals are perfectly aligned. Add a title and a company logo. Then, go to the Mobile Layout view and create a tailored view for phones.",
            resources: [
                "YouTube: 'Power BI Dashboard Design Tips'"
            ],
            tip: "Good design builds trust in your data. A sloppy report can make even the most accurate numbers seem questionable."
        },
        {
            day: 25,
            title: "Enhancing User Experience: Bookmarks & Buttons",
            objective: "Create a more app-like and guided experience for your users.",
            concepts: [
                "What Bookmarks are: Saving a state of a report page.",
                "Creating and updating bookmarks.",
                "Assigning bookmarks to Buttons.",
                "Creating page navigation with buttons."
            ],
            task: "Create two bookmarks on a report page: one with a slicer set to '2023' and another with it set to '2024'. Add two buttons to your canvas, 'View 2023 Data' and 'View 2024 Data', and link them to the respective bookmarks.",
            resources: [
                "Microsoft Learn: 'Create bookmarks in Power BI Desktop to share insights and build stories'"
            ]
        },
        {
            day: 26,
            title: "Advanced Interactions & Tooltips",
            objective: "Fine-tune how visuals interact and create custom, insightful tooltips.",
            concepts: [
                "Editing visual interactions (Filter, Highlight, None).",
                "Creating custom Report Page Tooltips.",
                "Drillthrough filters to navigate between pages."
            ],
            task: "Create a summary page and a detail page. Set up a drillthrough filter so that a user can right-click a product on the summary page and 'Drillthrough' to the detail page, which will be filtered to that specific product. Also, create a custom tooltip page that shows a small trend chart when you hover over a data point.",
            resources: [
                "YouTube: 'Power BI Report Page Tooltips - A Deep Dive'"
            ]
        },
        {
            day: 27,
            title: "Principles of Effective Dashboard Design",
            objective: "Learn the theory behind creating dashboards that communicate clearly and effectively.",
            concepts: [
                "Information hierarchy: Most important info top-left.",
                "Choosing the right visual for the right data.",
                "Avoiding clutter ('less is more').",
                "Using color intentionally.",
                "Data storytelling: Guiding the user through insights."
            ],
            task: "Find three Power BI dashboards online (e.g., in the Power BI Data Stories Gallery). Critique them based on the principles learned today. What do they do well? What could be improved? Sketch a layout for your own 'ideal' sales dashboard on paper.",
            resources: [
                "Blogs by Stephen Few or Cole Nussbaumer Knaflic ('Storytelling with Data')."
            ]
        },
        {
            day: 28,
            title: "Weekly Review & Report Makeover",
            objective: "Consolidate visualization and design skills from Week 4.",
            concepts: [
                "Review all visualization, formatting, and UX concepts from the week."
            ],
            task: "Take the very first report you built in Week 1. Apply everything you've learned this week to transform it into a professional, well-designed, and interactive report. It should include a custom theme, bookmarks for navigation, and custom tooltips.",
            resources: [
                "Your notes from the week."
            ],
isReview: true
        }
    ]
},
{
    title: "Phase 5: Consolidation & Real-World Project",
    duration: "Days 29-30",
    days: [
        {
            day: 29,
            title: "Capstone Project - Part 1: Plan, Prep, Model",
            objective: "Begin a project from scratch that simulates a real-world business request.",
            concepts: [
                "Defining business requirements.",
                "Data sourcing and profiling.",
                "Data cleaning and transformation plan.",
                "Data modeling (designing a schema)."
            ],
            task: "Define a business problem (e.g., 'Analyze global supermarket sales performance'). Find a suitable dataset from Kaggle or another source. Spend the day entirely in Power Query and the Model view. Clean the data meticulously. Build a perfect star schema. Do not build any visuals yet.",
            resources: [
                "Kaggle: 'Global Superstore' dataset or similar."
            ],
            tip: "Resist the urge to visualize! 80% of a great Power BI project is what happens before you drag a single chart onto the canvas."
        },
        {
            day: 30,
            title: "Capstone Project - Part 2: Build, Design, Publish",
            objective: "Complete the capstone project by building a comprehensive, professional dashboard.",
            concepts: [
                "Report building.",
                "DAX measure creation.",
                "Dashboard design and layout.",
                "Applying UX enhancements (bookmarks, tooltips).",
                "Publishing and final review."
            ],
            task: "Write at least 10-15 DAX measures to support your analysis. Build a complete, multi-page interactive report based on your data model. Make it beautiful and easy to use. Publish it to Power BI Service, create a dashboard, and share the link (if you're comfortable). You did it! You are a Power BI Hero!",
            resources: [
                "All the knowledge you have accumulated over the past 29 days."
            ]
        }
    ]
}
];
